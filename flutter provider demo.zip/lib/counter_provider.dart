import 'package:flutter/material.dart';

class CounterProvider extends ChangeNotifier {
  int counter = 0;

  void increamentCounter() {
    counter++;
    notifyListeners();
  }

  void decreamentCounter() {
    if (counter > 0) {
      // counter must be greater than 0 or equal to 0
      counter--;
      notifyListeners();
    }
  }
}
